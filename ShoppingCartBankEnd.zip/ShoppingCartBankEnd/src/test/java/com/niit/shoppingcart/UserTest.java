package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class UserTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		
		User user = (User) context.getBean("user");
		user.setId("R102");
		user.setName("Praise");
		user.setPassword("123");
		user.setMobile("9442286914");
		user.setMail("pr@gmail.com");
		user.setAddress("Chennai");
		
		userDAO.saveOrUpdate(user);
		
		
		}

}
